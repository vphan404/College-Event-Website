# College-Event-Website
COP4710 - Database Systems - Project\
Django Python React PostgresSQL
