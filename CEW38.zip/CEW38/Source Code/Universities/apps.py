from django.apps import AppConfig


class UniversitiesConfig(AppConfig):
    name = 'Universities'
