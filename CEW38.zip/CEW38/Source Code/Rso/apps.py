from django.apps import AppConfig


class RsoConfig(AppConfig):
    name = 'Rso'
