from django.contrib import admin
from .models import Rso
# Register your models here.
admin.site.register(Rso)